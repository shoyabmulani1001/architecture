"use client";

interface PlacementHeroProps {
    currentTab: string;
}

export default function PlacementHero({
    currentTab,
}: PlacementHeroProps) {
    return (
        <section
            className="relative h-[450px] flex items-center"
            style={{
                backgroundImage:
                    "url('/placement/placement-banner.jpg')",
                backgroundSize: "cover",
                backgroundPosition: "center",
            }}
        >
            <div className="absolute inset-0 bg-black/60" />

            <div className="max-w-[1440px] mx-auto px-4 lg:px-8 relative z-10">
                <div className="max-w-3xl">
                    <h1 className="text-white text-6xl font-bold mb-4">
                        Placements
                    </h1>

                    <p className="text-2xl text-white font-medium">
                        {currentTab}
                    </p>

                    <div className="w-24 h-1 bg-[var(--primary-color)] mt-4" />
                </div>
            </div>
        </section>
    );
}
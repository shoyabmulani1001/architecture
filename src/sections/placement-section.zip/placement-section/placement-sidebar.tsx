"use client";

import { placementTabs } from "./placement-data";

interface SidebarProps {
    activeTab: string;
    setActiveTab: (tab: string) => void;
}

export default function PlacementSidebar({
    activeTab,
    setActiveTab,
}: SidebarProps) {
    return (
        <div className="sticky top-36">
            <div className="bg-[#f7f7f7] rounded-xl p-6 shadow-sm">
                <h4 className="text-[var(--text-1)] mb-6">
                    Placements
                </h4>

                <div className="space-y-1">
                    {placementTabs.map((tab) => (
                        <button
                            key={tab.id}
                            onClick={() => setActiveTab(tab.id)}
                            className={`w-full text-left px-5 py-2 transition-all duration-300
                ${activeTab === tab.id
                                    ? "bg-[#3E4095] text-white"
                                    : "text-black border-b border-gray-200 hover:text-[#3E4095]"
                                }
              `}
                        >
                            {tab.title}
                        </button>
                    ))}
                </div>
            </div>
        </div>
    );
}
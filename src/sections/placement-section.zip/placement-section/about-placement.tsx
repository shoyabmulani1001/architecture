import Image from "next/image";
import { FaCheckCircle } from "react-icons/fa";

export default function AboutPlacement() {
    const placementData = {
        coordinator: {
            name: "Shweta Anil Borse",
            designation: "MBA HR",
            experience: "6 Years",
            image: "/placement/tpo.jpg",
        },

        title:
            "Training & Placement Cell – Building Careers with Purpose",

        description: [
            "At DYPIMED, the Training & Placement Cell serves as a central pillar in preparing students to become industry-ready professionals. Through a strategic blend of academic rigor, corporate exposure, and skill development initiatives, we ensure that our students confidently meet the evolving demands of today's competitive global market.",

            "Our Cell operates with a structured approach that includes industry-oriented training programs, communication and leadership development sessions, guest lectures, management activities, live projects, and continuous mentorship. By fostering long-standing associations with leading organizations and leveraging a strong alumni network, we create impactful opportunities for internships and final placements across diverse sectors.",
        ],

        aimTitle: "Aim of Training & Placement Cell",

        aims: [
            "To provide 100% placement support to aspirants by offering training, dedicated resources and best career opportunities.",

            "To enhance the employability skills of students, enabling them to perform effectively in corporate environments.",

            "To prepare aspirants to meet dynamic corporate expectations and professional standards.",

            "To strengthen industry–academia partnerships and encourage alumni involvement for knowledge sharing and growth.",

            "To help each student acquire new skills, refine existing capabilities, and evolve into a confident, competent, and future-ready professional.",
        ],

        conclusion:
            "We take pride in our consistent placement successes and our commitment to excellence. Through focused training, dynamic leadership, and value-driven guidance, the Training & Placement Cell at DYPIMED remains unwavering in its mission—empowering students not only to secure rewarding opportunities but to build impactful, sustainable careers.",
    };

    return (
        <section>
            <div className="space-y-12">

                {/* Top Section */}
                <div className="grid lg:grid-cols-[340px_1fr] gap-12">

                    {/* Profile Card */}
                    <div className="bg-white rounded-2xl shadow-md overflow-hidden h-fit border border-gray-200">
                        <Image
                            src={placementData.coordinator.image}
                            alt={placementData.coordinator.name}
                            width={400}
                            height={500}
                            className="w-full h-[420px] object-cover"
                        />

                        <div className="p-7">
                            <h3 className="text-[32px] font-bold text-black mb-2">
                                {placementData.coordinator.name}
                            </h3>

                            <p className="text-lg text-black">
                                {placementData.coordinator.designation}
                            </p>

                            <p className="text-lg text-black mt-1">
                                Experience - {placementData.coordinator.experience}
                            </p>
                        </div>
                    </div>

                    {/* Main Content */}
                    <div>
                        <h2 className="text-[42px] font-bold text-black underline leading-tight mb-8">
                            {placementData.title}
                        </h2>

                        {placementData.description.map((paragraph, index) => (
                            <p
                                key={index}
                                className="text-lg lg:text-xl leading-10 text-black mb-8"
                            >
                                {paragraph}
                            </p>
                        ))}
                    </div>
                </div>

                {/* Aim Section */}
                <div>
                    <h3 className="text-[38px] font-bold text-black underline mb-10">
                        {placementData.aimTitle}
                    </h3>

                    <div className="space-y-8">
                        {placementData.aims.map((item, index) => (
                            <div
                                key={index}
                                className="flex items-start gap-4"
                            >
                                <FaCheckCircle
                                    size={22}
                                    className="text-black mt-2 shrink-0"
                                />

                                <p className="text-lg lg:text-xl leading-10 text-black">
                                    {item}
                                </p>
                            </div>
                        ))}
                    </div>

                    <p className="mt-12 text-lg lg:text-xl leading-10 text-black">
                        {placementData.conclusion}
                    </p>
                </div>
            </div>
        </section>
    );
}